package com.example.orbitalcannon;

import org.bukkit.configuration.Configuration;

import java.util.List;

public class Config {

    public final int countPerShot;
    public final int maxShots;
    public final int spawnHeight;
    public final int fuseTicks;
    public final int spreadRadius;
    public final int delayBetweenTntTicks;
    public final int cooldownSeconds;
    public final int maxRange;
    public final boolean allowCreative;
    public final List<String> worldWhitelist;
    public final int protectRadius;
    public final boolean logStrikes;
    public final boolean announceOnStrike;

    public Config(Configuration cfg) {
        this.countPerShot = cfg.getInt("tnt.count_per_shot", 8);
        this.maxShots = cfg.getInt("tnt.max_shots", 5);
        this.spawnHeight = cfg.getInt("tnt.spawn_height", 120);
        this.fuseTicks = cfg.getInt("tnt.fuse_ticks", 60);
        this.spreadRadius = cfg.getInt("tnt.spread_radius", 6);
        this.delayBetweenTntTicks = cfg.getInt("tnt.delay_between_tnt_ticks", 2);
        this.cooldownSeconds = cfg.getInt("cooldown_seconds", 30);
        this.maxRange = cfg.getInt("max_range", 200);
        this.allowCreative = cfg.getBoolean("allow_creative", true);
        this.worldWhitelist = cfg.getStringList("world_whitelist");
        this.protectRadius = cfg.getInt("safety.protect_radius", 30);
        this.logStrikes = cfg.getBoolean("log_strikes", true);
        this.announceOnStrike = cfg.getBoolean("announce_on_strike", true);
    }

    public boolean isWorldAllowed(String worldName) {
        return worldWhitelist == null || worldWhitelist.isEmpty() || worldWhitelist.contains(worldName);
    }
}
