package com.example.orbitalcannon;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExplodeEvent;

import java.util.List;

public class ExplosionListener implements Listener {

    private final OrbitalCannonPlugin plugin;

    public ExplosionListener(OrbitalCannonPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityExplode(EntityExplodeEvent event) {
        // If config says no_block_damage = true, cancel block list (prevent block damage)
        boolean noBlock = plugin.getConfig().getBoolean("no_block_damage", false);
        if (noBlock) {
            // Clear the block list so no blocks are destroyed
            List<?> blocks = event.blockList();
            blocks.clear();
        }
    }
}
