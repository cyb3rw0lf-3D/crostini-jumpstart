package com.example.orbitalcannon;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class StrikeManager {

    private final OrbitalCannonPlugin plugin;
    private final Config config;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public StrikeManager(OrbitalCannonPlugin plugin, Config config) {
        this.plugin = plugin;
        this.config = config;
    }

    public boolean isOnCooldown(UUID player) {
        Long end = cooldowns.get(player);
        if (end == null) return false;
        return System.currentTimeMillis() < end;
    }

    public long getRemainingCooldown(UUID player) {
        Long end = cooldowns.get(player);
        if (end == null) return 0;
        long remMs = end - System.currentTimeMillis();
        return Math.max(0, remMs / 1000);
    }

    public void setCooldown(UUID player, int seconds) {
        cooldowns.put(player, System.currentTimeMillis() + seconds * 1000L);
    }

    public void launchStrike(Player caller, Location target, int shots) {
        World w = target.getWorld();

        if (config.logStrikes) {
            plugin.getLogger().info("Orbital strike by " + caller.getName() + " at " +
                    target.getBlockX() + "," + target.getBlockY() + "," + target.getBlockZ() +
                    " [" + shots + " shots]");
        }

        if (config.announceOnStrike) {
            Bukkit.broadcastMessage("§cOrbital strike incoming at coordinates: " +
                    target.getBlockX() + " " + target.getBlockZ());
        }

        final int totalShots = shots;
        final int intervalTicks = 20; // 1 second between shots

        // schedule repeating task that cancels itself after totalShots
        final BukkitTask[] handle = new BukkitTask[1];
        handle[0] = Bukkit.getScheduler().runTaskTimer(plugin, new Runnable() {
            int shotCount = 0;
            @Override
            public void run() {
                if (shotCount >= totalShots) {
                    handle[0].cancel();
                    return;
                }
                fireOneShot(w, target);
                shotCount++;
            }
        }, 0L, intervalTicks);
    }

    private void fireOneShot(World world, Location target) {
        int count = config.countPerShot;
        int spawnY = config.spawnHeight;
        double cx = target.getX();
        double cz = target.getZ();

        for (int i = 0; i < count; i++) {
            final int idx = i;
            long delayTicks = (long) idx * Math.max(1, config.delayBetweenTntTicks);

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                double angle = ThreadLocalRandom.current().nextDouble(0, Math.PI * 2);
                double radius = ThreadLocalRandom.current().nextDouble(0, config.spreadRadius);
                double dx = Math.cos(angle) * radius;
                double dz = Math.sin(angle) * radius;
                Location spawnLoc = new Location(world, cx + dx, spawnY, cz + dz);
                TNTPrimed tnt = (TNTPrimed) world.spawnEntity(spawnLoc, EntityType.PRIMED_TNT);
                tnt.setFuseTicks(config.fuseTicks);
                // give slight downward velocity
                tnt.setVelocity(tnt.getVelocity().setY(-0.05));
            }, delayTicks);
        }
    }
}
