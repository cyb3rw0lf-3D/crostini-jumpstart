package com.example.orbitalcannon;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

public class OrbitalCommand implements CommandExecutor {

    private final OrbitalCannonPlugin plugin;
    private final Config config;
    private final StrikeManager manager;

    public OrbitalCommand(OrbitalCannonPlugin plugin, Config config, StrikeManager manager) {
        this.plugin = plugin;
        this.config = config;
        this.manager = manager;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Only players may call orbital strikes.");
            return true;
        }

        if (!p.hasPermission("orbital.use")) {
            p.sendMessage("You don't have permission to use that.");
            return true;
        }

        // cooldown
        if (!p.hasPermission("orbital.admin") && manager.isOnCooldown(p.getUniqueId())) {
            long remaining = manager.getRemainingCooldown(p.getUniqueId());
            p.sendMessage("You are on cooldown for " + remaining + " seconds.");
            return true;
        }

        if (args.length == 0) {
            p.sendMessage("Usage: /orbital <player | x y z> [shots]");
            return true;
        }

        Location target;
        int shots = 1;
        try {
            if (args.length >= 3 && isDouble(args[0]) && isDouble(args[1]) && isDouble(args[2])) {
                // coords
                double x = Double.parseDouble(args[0]);
                double y = Double.parseDouble(args[1]);
                double z = Double.parseDouble(args[2]);
                target = new Location(p.getWorld(), x, y, z);
                if (args.length >= 4 && isInteger(args[3])) {
                    shots = Integer.parseInt(args[3]);
                }
            } else {
                // assume player name
                OfflinePlayer op = Bukkit.getPlayer(args[0]);
                if (op == null || !op.isOnline()) {
                    p.sendMessage("Target player not found or not online.");
                    return true;
                }
                target = ((Player) op).getLocation();
                if (args.length >= 2 && isInteger(args[1])) shots = Integer.parseInt(args[1]);
            }
        } catch (NumberFormatException ex) {
            p.sendMessage("Invalid number format.");
            return true;
        }

        if (shots < 1) shots = 1;
        if (shots > config.maxShots && !p.hasPermission("orbital.admin")) {
            p.sendMessage("Too many shots; max is " + config.maxShots);
            return true;
        }

        if (p.getLocation().distanceSquared(target) > (long)config.maxRange * config.maxRange && !p.hasPermission("orbital.admin")) {
            p.sendMessage("Target is out of range.");
            return true;
        }

        if (!config.isWorldAllowed(target.getWorld().getName())) {
            p.sendMessage("Orbital strikes are not allowed in that world.");
            return true;
        }

        // simple spawn protection: world spawn radius
        Location spawn = target.getWorld().getSpawnLocation();
        if (spawn.distanceSquared(target) <= (double)config.protectRadius * config.protectRadius && !p.hasPermission("orbital.admin")) {
            p.sendMessage("Target is too close to spawn or protected area.");
            return true;
        }

        manager.launchStrike(p, target, shots);
        p.sendMessage("Orbital strike launched at " + target.getBlockX() + " " + target.getBlockY() + " " + target.getBlockZ());

        if (!p.hasPermission("orbital.admin")) {
            manager.setCooldown(p.getUniqueId(), config.cooldownSeconds);
        }
        return true;
    }

    private boolean isDouble(String s) {
        try { Double.parseDouble(s); return true; } catch (Exception e) { return false; }
    }
    private boolean isInteger(String s) {
        try { Integer.parseInt(s); return true; } catch (Exception e) { return false; }
    }
}
