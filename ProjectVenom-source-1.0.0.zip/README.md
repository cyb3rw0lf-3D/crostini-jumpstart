OrbitalCannon - PaperMC plugin (recreation)
==========================================

Build:
  - Java 21
  - Maven
  - Run: mvn clean package

Resulting JAR: target/orbitalcannon-paper-1.0.0.jar

Drop in server plugins/ and start Paper 1.21.10.
