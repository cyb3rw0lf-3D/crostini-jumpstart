package com.example.orbitalcannon;

import org.bukkit.plugin.java.JavaPlugin;

public final class OrbitalCannonPlugin extends JavaPlugin {

    private static OrbitalCannonPlugin instance;
    private Config config;
    private StrikeManager strikeManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        this.config = new Config(getConfig());
        this.strikeManager = new StrikeManager(this, config);

        // Register explosion listener for no-block-damage mode
        getServer().getPluginManager().registerEvents(new ExplosionListener(this), this);

        getCommand("orbital").setExecutor(new OrbitalCommand(this, config, strikeManager));
        getLogger().info("OrbitalCannon enabled (Paper 1.21.10)");
    }

    @Override
    public void onDisable() {
        getLogger().info("OrbitalCannon disabled");
        instance = null;
    }

    public static OrbitalCannonPlugin getInstance() {
        return instance;
    }

    public Config getOrbitalConfig() {
        return config;
    }

    public StrikeManager getStrikeManager() {
        return strikeManager;
    }
}
